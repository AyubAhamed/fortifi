export { default as chart } from "./Chart.png";
export { default as f_logo_dark } from "./FortiFi-Logo-dark-alpha-press.png";
export { default as barSmallCrat } from "./bar-chart 1.svg";
export { default as logo } from "./logo.svg";
export { default as platform } from "./platform.svg";
export { default as savax } from "./savax.svg";
export { default as satistics } from "./statistics 1.svg";
export { default as usdc } from "./usdc.svg";
export { default as user } from "./user 1.png";
