export { default as bitcoin } from "./bitcoin.svg";
